# PS-010: Dysarthric Code-Switched Acoustic Dataset
Contains acoustic speech samples with motor speech pathology characteristics (spastic phonation, vocal tremors) and intra-sentential code-switching.
- `audio/`: 16kHz mono audio recordings.
- `transcripts_and_phonemes.json`: Target transcripts, language shift indicators, and canonical IPA phoneme sequences for dual-codebook VQ-VAE training.
