# PS-008: Federated Non-IID Fraud Dataset
Contains 10 distributed institutional banking node datasets.
- `clients/client_bank_01.csv` to `client_bank_10.csv`: 10 PCA transaction features per row with fraud classification labels.
- Clients 1-5: Extreme non-IID class imbalance.
- Clients 6-8: Concept drift nodes.
- Clients 9-10: Adversarial Byzantine poisoning nodes (inverted labels).
