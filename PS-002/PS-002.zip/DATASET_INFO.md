# PS-002: Attack Profiles & BPF Map Schemas
Contains attack traffic parameters simulating 10 Mpps volumetric and layer 7 DDoS vectors.
- `attack_profiles.json`: Configuration for SYN Flood, UDP reflection, and HTTP/2 Rapid Reset attacks.
- `bpf_maps_schema.h`: C header defining LPM trie and hash map schemas for wire-speed kernel injection.
