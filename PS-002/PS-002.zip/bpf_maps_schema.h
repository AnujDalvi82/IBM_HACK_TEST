// BPF Map definitions for XDP wire-speed filtering
#ifndef __BPF_MAPS_SCHEMA_H
#define __BPF_MAPS_SCHEMA_H

struct bpf_lpm_trie_key {
    unsigned int prefixlen;
    unsigned int ip_addr;
};

struct drop_rule_value {
    unsigned long long packet_count;
    unsigned long long byte_count;
    unsigned int drop_action; // 1 = XDP_DROP, 2 = XDP_PASS
};
#endif
