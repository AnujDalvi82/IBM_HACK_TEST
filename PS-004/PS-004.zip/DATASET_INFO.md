# PS-004: Multi-Agent Marketplace & Adversarial Verification
- `orderbook_sample_1000.json`: 1,000 multi-agent transaction bids with budget and quantity limits.
- `adversarial_jailbreaks.json`: Adversarial proposals attempting price fixing, zero-dollar transfers, and budget overruns for Z3 SMT solver testing.
