# PS-009: ISPD 2005 VLSI Placement Benchmark (Adaptec1)
Contains the standard industrial ASIC placement netlist from the ISPD 2005 placement contest:
- `adaptec1.nodes`: Cell definitions, node names, and macro dimensions (211,447 nodes).
- `adaptec1.nets`: Electrical netlist connectivity (221,142 nets).
- `adaptec1.scl`: Standard cell placement rows and site configurations.
- `adaptec1.pl`: Initial placement coordinates and fixed/movable status.
- `adaptec1.wts`: Net weights.
