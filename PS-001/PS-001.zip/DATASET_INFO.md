# PS-001: Synthetic Workload & Trace Specification
Contains 500 concurrent variable-length prompt streams distributed across 8 tenants.
- `synthetic_workload_500_streams.json`: Contains arrival timestamps, prompt tokens, shared system prompt prefix, and generation targets.
- Designed to test:
  1. Non-contiguous block allocation (16 tokens/block).
  2. Prefix caching via Radix Tree on common system prompt tokens.
  3. Copy-on-Write (CoW) branching across tenants.
  4. 12-hour stress test for memory leaks and OOM avoidance under 24GB VRAM target.
